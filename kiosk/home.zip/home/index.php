<?php
error_reporting(E_ALL & ~E_NOTICE);
session_start();


if(isset($_SESSION['HRMS_ID'])){
	header('Location: php/user.php');
}

if($_POST['login']){
	include_once("php/connection.php");
	$email=strip_tags($_POST['email']);
	$password=strip_tags($_POST['password']);

	$sql = "SELECT HRMS_ID, email, password FROM employee WHERE email = '$email'";
	$query = mysqli_query($dbCon,$sql);
 
	if($query){
		$row = mysqli_fetch_assoc($query);
		$userId = strip_tags($row['HRMS_ID']);
		$dbEmail = strip_tags($row['email']);
		$dbPassword = strip_tags($row['password']);
	}
	if (strlen($email)>0 && strlen($password)>0) {
		if(strcmp($email, $dbEmail)==0 && strcmp($password, $dbPassword)==0){
			$_SESSION['email'] = $email;
			$_SESSION['HRMS_ID'] = $userId;
			header('Location: php/user.php');
		}else{
			header('Location: index.php?alert=' . urlencode('Username and Password Incorrect.'));
		}
	} else {
		header('Location: index.php?alert=' . urlencode('Username and/or Password Fields Empty.'));
	}
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Calpers</title>
    <meta charset="utf-8">
    <!--viewport is just the screen make consistent in all pages-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/calpers_style.css">
	
	<script>
	var filter = "name";
	var search = "";
	var asc = true;
		
	function setAlert()
	{
		var thisurl = document.URL;
		
		if (thisurl.indexOf("=") > -1) {
			var left = thisurl.indexOf("=") + 1;
			var alert = thisurl.substring(left, thisurl.length);
			
			if (alert.indexOf("+") > -1)
				alert = alert.split("+").join(" ");
			if (alert.indexOf("%0A") > -1)
				alert = alert.split("%0A").join("<br>");
			if (alert.indexOf("%3A") > -1)
				alert = alert.split("%3A").join(":");
			if (alert.indexOf("%09") > -1)
				alert = alert.split("%09").join("&nbsp;&nbsp;&nbsp;&nbsp;");
			if (alert.indexOf("%2F") > -1)
				alert = alert.split("%2F").join("/");
			
			document.getElementById("err-mes").innerHTML = alert;
			$('#popUpWindowLogin').modal('show');
		}
	}
		
		function showList(str)
		{
			search = str;
			var xmlhttp = new XMLHttpRequest({mozSystem: true});
			var url = "http://localhost/calpers/home/php/table_create.php?search=";
			
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
					document.getElementById("empTable").innerHTML = xmlhttp.responseText;
				}
			};
			
			xmlhttp.open("GET", url + str + "&filter=" + filter + "&ascending=" + asc, true);
			xmlhttp.send();
		}
		
		function changeFilter($name)
		{
			switch($name)
			{
				case("name"):
					if (filter != "name") { asc = true; }
					else { asc = !asc; }
						
					filter = "name";
					break;
				case("job_title"):
					if (filter != "job_title") { asc = true; }
					else
						asc = !asc;

					filter = "job_title";
					break;
				case("building"):
					if (filter != "building") { asc = true; }
					else
						asc = !asc;
						
					filter = "building";
					break;
				case("floor"):
					if (filter != "floor") { asc = true; }
					else { asc = !asc; }
						
					filter = "floor";
					break;
				default:
					filter = "name";
					asc = true;
			}
			
			showList(search);
		}
	</script>
	
</head>

<body>
<!--This part of the html controls the navagation bar-->
	<nav class="navbar navbar-inverse">
		
		<div class="container-fluid">
		<!--Logo-->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavBar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="#" class="navbar-brand">CALPERS</a>
			</div>

		<!--Menu Items-->
		<div class="collapse navbar-collapse" id="mainNavBar" align="center">
			<ul class="nav navbar-nav">
				<!--The href is the bottom the lets you go to different page-->
				<li class="active"><a href="#">Home</a></li>
				<li><a href="#" class="btn btn-link" role="button" data-toggle="modal" data-target="#popUpWindowLogin">Log In</a></li>

			</ul>


		</div>
		
		<div class="flexsearch">
		  <div class="flexsearch--wrapper">
			<form class="flexsearch--form">
			  <div class="flexsearch--input-wrapper">
				<input class="flexsearch--input" type="text" placeholder="Search" onkeyup="showList(this.value)" name="val">
			  </div>
			  <input class="flexsearch--submit" text="submit" onsubmit="showList(val)" value="&#10140;"/>
			</form>
		  </div>
		</div>
		
	</nav>

		<div class="modal fade" id="popUpWindowLogin">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h3 class ="modal-title">Log-In</h3>
					</div>
					<form id="loginForm" action"index.php" method="post">
							<div class="modal-body">
									<div class="form-group">
										<input type="text" class="form-control" placeholder="Username" name="email"/><br/>
										<input type="password" class="form-control" placeholder="Password" name="password"/><br/>
										<strong id="err-mes"></strong>
									</div>
							</div>

							<div class="modal-footer">
										<input type="submit" name="login" class="btn btn-primary btn-block" value="Log In"/>
							</div>
					</form>
				</div>
			</div>
			<!--button-->
		</div>	
	
</div>

<!--This part of the html is for the Log In PopUP-->
	<div class="modal fade" id="popUpWIndowRegister">
		<div class="modal-dialog">
			<div class="modal-content">

			<!--Header-->
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h3 class="modal-title">Register</h3>
			</div>

			<!--body form-->
			<div class="modal-body">
				<form class="Register-form" role="form" action="http://localhost/HTML PHP/Register.php" method="post">
					<div class="form-group">
						<input type="email" class="form-control" placeholder="Email">
					</div>
					<div class="form-group">
						<input type="password" class="form-control" placeholder="Password">
					</div>
					<div class="form-group">
						<input type="email" class="form-control" placeholder="Confirm-Email">
					</div>
					<div class="form-group">
						<input type="password" class="form-control" placeholder="Confirm-Password">
					</div>
				</form>
			</div>

			<!--button-->
			<div class="modal-footer">
				<button class="btn btn-primary btn-block">Register</button>
			</div>
			</div>
		</div>
	</div>

	<p><div id="empTable"> </div></p>
	<script> showList(""); 	setAlert(); </script>

</body>
</html>