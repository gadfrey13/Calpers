<!DOCTYPE html>
<html lang="en">
<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Wayfinding</title>
	<meta name="description" content="">
	<!--viewport is just the screen make consistent in all pages-->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
	<!--script src="bower_components/jquery/dist/jquery.js"></script-->
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
	<script type="text/javascript" src="src/jquery.wayfinding.js"></script>
	
	<style>
	.map{
	  display: inline-block; /* shrink to fit */
	  width: 60%;
	  position: relative;
	}
	.map::after{
	  padding-top: 56.25%; /* percentage of containing block _width_ */
	  display: block;
	  content: '';
	}
	</style>
</head>


<body>
<!--This part of the html controls the navagation bar-->
	<nav class="navbar navbar-inverse">
		
		<div class="container-fluid">
		<!--Logo-->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavBar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="../index.php" class="navbar-brand">CALPERS</a>
				<label text="text" name="hrms" id="hrms" hidden></label>
				<label text="text" name="grid" id="grid" hidden></label>
				
			</div>

			<!--Menu Items-->
			<div class="collapse navbar-collapse" id="mainNavBar" align="center">
				<ul class="nav navbar-nav">
					<!--The href is the bottom the lets you go to different page-->
					<li class="active"><a href="../index.php">Home</a></li>

				</ul>


			</div>
	
		</div>
	</nav>

	<div class="map" id="content">
		<div id="myMaps"></div>
	</div>
	
	<script>
		$(document).ready(function () {
			'use strict';
			var grid;
			var thisurl = document.URL;
			
			var left = thisurl.indexOf("=") + 1;
			grid = thisurl.substring(left, thisurl.length);
			
			$('#myMaps').wayfinding({
				'maps': [
					{'path': 'floorplan/fullmap.svg', 'id': 'floor1'},
				],
				'path': {
					width: 2,
					color: 'blue',
					radius: 5,
					speed: 8
				},
				'startpoint': function () {
					return 'lcd.1';
				},
				'defaultMap': 'floor1',
				'showLocation': true
			}, function(){
				console.log('callback reached');
			});
			
			
			$('#myMaps').wayfinding('routeTo', grid);
		});
		
	</script>
</body>
</html>