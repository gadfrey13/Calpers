<?php
	header('Access-Control-Allow-Origin: *'); 
	$servername = "localhost";
	$username 	= "root";
	$password 	= "";
	$dbName 	= "calpers";
	
	$subject = "Contact Information";
	$header  = "From: Calpers Employee Information Kiosk";
	
	// Make Connection
	$connection = new mysqli($servername, $username, $password, $dbName);
	
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	
	$hrms = $_POST["hrms"];
	$to = $_POST["email"];
	
	if ($hrms !== "" && $to !== "") {
		$query = "SELECT first_name, last_name, email, desk_phone, mobile_phone, job_title, building, floor
			FROM employee 
			WHERE HRMS_ID = $hrms";
	}
	else
	{
		return null;
	}
	
	$result = mysqli_query($connection, $query);
	mysqli_close($connection);

	$desk .= substr($result["desk_phone"],0,1) . " (" . substr($result["desk_phone"],1,3) . ") " 
	. substr($result["desk_phone"],4,3) . "-" . substr($result["desk_phone"], 7, 4) . "</td>\n";
	
	$mobile .= substr($result["mobile_phone"],0,1) . " (" . substr($result["mobile_phone"],1,3) . ") " 
	. substr($result["mobile_phone"],4,3) . "-" . substr($result["mobile_phone"], 7, 4) . "</td>\n";
	
	$message = $result['first_name'] . " " . $result['last_name'] . "\n" 
		. $result['job_title'] . "\n"
		. $result['building'] . ", Floor " . $result['floor']
		. "Desk Phone: " . $desk
		. "Mobile Phone:" . $mobile
		. "Email: " . $result['email'];
		

	mail ($to, $subject, $message, $header);
	
	header('Location: ../user-profile.html?='.$result['HRMS_ID']);
?>