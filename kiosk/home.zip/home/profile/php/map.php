<?php 
	echo file_get_contents("icons/my-icon.svg"); 
	
	if(isset($_SESSION['HRMS_ID'])){
		header('Location: usermap.html');
	} else {
		header('Location: standardmap.html');
	}
	
	
?>

