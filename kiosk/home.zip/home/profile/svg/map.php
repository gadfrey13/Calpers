<?php
	error_reporting(E_ALL & ~E_NOTICE);
	session_start();
	
	if(isset($_SESSION['HRMS_ID'])){
		header('Location: usermap.html');
	}

	if($_POST['login']){
		include_once("../php/connection.php");
		$email=strip_tags($_POST['email']);
		$password=strip_tags($_POST['password']);

		$sql = "SELECT HRMS_ID, email, password FROM employee WHERE email = '$email'";
		$query = mysqli_query($dbCon,$sql);
	 
		if($query){
			$row = mysqli_fetch_assoc($query);
			$userId = strip_tags($row['HRMS_ID']);
			$dbEmail = strip_tags($row['email']);
			$dbPassword = strip_tags($row['password']);
		}
		if (strlen($email)>0 && strlen($password)>0) {
			if(strcmp($email, $dbEmail)==0 && strcmp($password, $dbPassword)==0){
				$_SESSION['email'] = $email;
				$_SESSION['HRMS_ID'] = $userId;
				header('Location: usermap.html');
			}else{
				header('Location: map.php?alert=' . urlencode('Username and Password Incorrect.'));
			}
		} else {
			header('Location: map.php?alert=' . urlencode('Username and/or Password Fields Empty.'));
		}
	}
?>

<script>
	function setAlert()
	{
		var thisurl = document.URL;
		
		if (thisurl.indexOf("=") > -1) {
			var left = thisurl.indexOf("=") + 1;
			var alert = thisurl.substring(left, thisurl.length);
			
			if (alert.indexOf("+") > -1)
				alert = alert.split("+").join(" ");
			if (alert.indexOf("%0A") > -1)
				alert = alert.split("%0A").join("<br>");
			if (alert.indexOf("%3A") > -1)
				alert = alert.split("%3A").join(":");
			if (alert.indexOf("%09") > -1)
				alert = alert.split("%09").join("&nbsp;&nbsp;&nbsp;&nbsp;");
			if (alert.indexOf("%2F") > -1)
				alert = alert.split("%2F").join("/");
			
			document.getElementById("err-mes").innerHTML = alert;
			$('#popUpWindowLogin').modal('show');
		}
	}
		
</script>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Wayfinding</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width">
	<link rel="stylesheet" href="styles/example.css">
	
    <!--viewport is just the screen make consistent in all pages-->
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/my.css">
</head>


<body>
<!--This part of the html controls the navagation bar-->
	<nav class="navbar navbar-inverse">
		
		<div class="container-fluid">
		<!--Logo-->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavBar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="../index.php" class="navbar-brand">CALPERS</a>
			</div>

		<!--Menu Items-->
		<div class="collapse navbar-collapse" id="mainNavBar" align="center">
			<ul class="nav navbar-nav">
				<!--The href is the bottom the lets you go to different page-->
				<li class="active"><a href="../index.php">Home</a></li>
				<li><a href="#" class="btn btn-link" role="button" data-toggle="modal" data-target="#popUpWindowLogin">Log In</a></li>

			</ul>


		</div>
		
			<div class="modal fade" id="popUpWindowLogin">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h3 class ="modal-title">Log-In</h3>
						</div>
						
						<form id="loginForm" action="map.php" method="post">
								<div class="modal-body">
										<div class="form-group">
											<input type="text" class="form-control" placeholder="Username" name="email"/><br/>
											<input type="password" class="form-control" placeholder="Password" name="password"/><br/>
											<strong id="err-mes"></strong>
										</div>
								</div>

								<div class="modal-footer">
									<input type="submit" name="login" class="btn btn-primary btn-block" value="Log In"/>
								</div>
						</form>
					</div>
				</div>
		<!--button-->
			</div>	
	
		</div>
	</nav>

	
	<body>
		<div id="content">
			<div id="myMaps">
			</div>
		</div>
		
			<!--script src="bower_components/jquery/dist/jquery.js"></script-->
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
			<script src="src/jquery.wayfinding.js"></script>
	
		<script>
		
			function route()
			{
				//route to employee option
				$('#controls #endSelect').change(function () {
					$('#myMaps').wayfinding('routeTo', '3150058');
				});
			}
            
			$(document).ready(function () {
				'use strict';
				$('#myMaps').wayfinding({
					'maps': [
						{'path': 'floorplan/fullmap.svg', 'id': 'floor1'},
					],
					'path': {
						width: 2,
						color: 'blue',
						radius: 5,
						speed: 8
					},
					'startpoint': function () {
						return 'lcd.1';
					},
					'defaultMap': 'floor1',
					'showLocation': true
				}, function(){
					console.log('callback reached');
				});

				//make the floor buttons clickable
				$('#controls button').click(function () {
					$('#myMaps').wayfinding('currentMap', $(this).prop('id'));
				});
				
                //kiosk Selection
				$('#controls #beginSelect').change(function () {
					$('#myMaps').wayfinding('startpoint', $(this).val());
					if ($('#endSelect').val() !== '') {
						$('#myMaps').wayfinding('routeTo', $('#endSelect').val());
					}
				});
                //route to employee option
				$('#controls #endSelect').change(function () {
					$('#myMaps').wayfinding('routeTo', '3150058');
				});
                //create route to clicked room
				$('#myMaps').on('wayfinding:roomClicked', function(e, r) {
					$('#endSelect option[value="' + r.roomId + '"]').attr('selected', true);
				});

			});
		</script>
	</body>
</html>

	
<script> setAlert(); </script>
</body>
</html>