<?php
error_reporting(E_ALL & E_NOTICE);
session_start();

if(isset($_SESSION['HRMS_ID'])){
  
	$connect = include_once("connection.php");
	$userId = $_SESSION['HRMS_ID'];
	$username = $_SESSION['email'];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Calpers</title>
    <meta charset="utf-8">
    <!--viewport is just the screen make consistent in all pages-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="http://localhost/calpers/home/css/my.css">


<script>
	function setAlert()
	{
		var thisurl = document.URL;
		
		if (thisurl.indexOf("=") > -1) {
			var left = thisurl.indexOf("=") + 1;
			var alert = thisurl.substring(left, thisurl.length);
			
			if (alert.indexOf("+") > -1)
				alert = alert.split("+").join(" ");
			if (alert.indexOf("%0A") > -1)
				alert = alert.split("%0A").join("<br>");
			if (alert.indexOf("%3A") > -1)
				alert = alert.split("%3A").join(":");
			if (alert.indexOf("%09") > -1)
				alert = alert.split("%09").join("&nbsp;&nbsp;&nbsp;&nbsp;");
			
			document.getElementById("err-mes").innerHTML = alert;
		}
	}

</script>
	
</head>

<body>
<!--This part of the html controls the navagation bar-->
	<nav class="navbar navbar-inverse">
		<div class="container-fluid">
		<!--Logo-->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavBar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="#" class="navbar-brand">CALPERS</a>
			</div>

		<!--Menu Items-->
		<div class="collapse navbar-collapse" id="mainNavBar" align="center">
			<ul class="nav navbar-nav">
				<!--The href is the bottom the lets you go to different page-->
				<li class="active"><a href="#">Edit-Profile</a></li>
				<li class=""><a href="user.php">User</a></li>
			</ul>

		<ul class="nav navbar-nav navbar-right">
				<form class="btn btn-link" action="logout.php">
					<input type="submit" value="LogOut">
				</form>
		</ul>

		</div>

		

	</nav>
<div class="container">
    <h1>Edit Profile</h1>
  	<hr>
	<div class="row">
      <!-- left column --><!--<a href="#myModal" role="button" class="btn btn-default" data-toggle="modal">Launch demo modal</a>-->

<div id="myModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			<h3 id="myModalLabel">Modal header</h3>
	</div>
	<div class="modal-body">
		<p>One fine body…</p>
	</div>
	<div class="modal-footer">
		<button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
		<button class="btn btn-primary">Save changes</button>
	</div>
</div>
</div>
</div><!--<a href="#" class="btn btn-default" id="openBtn">Open modal</a>-->

<div id="myModal" class="modal fade" tabindex="-1" role="dialog">
<div class="modal-dialog">
	<div class="modal-content">
		<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal">×</button>
			<h3>Modal header</h3>
	</div>
	<div class="modal-body">
		<p>My modal content here…</p>
	</div>
	<div class="modal-footer">
		<button class="btn" data-dismiss="modal">Close</button>
	</div>
	</div>
</div>
</div>
<!--
<ul class="nav nav-tabs">
<li><a href="#">Tab1</a></li>
<li><a href="#">Tab2</a></li>
<li class="dropdown">
<a class="dropdown-toggle" data-toggle="dropdown" href="#">Tab3 <b class="caret"></b></a>
<ul class="dropdown-menu">
	<li><a href="#">Three</a></li>
	<li><a href="#">Four</a></li>
</ul>
</li>
</ul>

<input type="text" class="span3" data-provide="typeahead" data-items="4" data-source="[&quot;alpha&quot;,&quot;beta&quot;,&quot;charlie&quot;,&quot;delta&quot;,&quot;epsilon&quot;,&quot;frank&quot;,&quot;gamma&quot;,&quot;trot&quot;,&quot;zulu&quot;]"><a href="#" class="btn btn-default" id="openBtn">Open modal</a>
-->
<div id="myModal" class="modal fade" tabindex="-1" role="dialog">
<div class="modal-dialog">
	<div class="modal-content">
		<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal">×</button>
			<h3>Modal header</h3>
	</div>
	<div class="modal-body">
		<p>My modal content here…</p>
	</div>
	<div class="modal-footer">
		<button class="btn" data-dismiss="modal">Close</button>
	</div>
	</div>
</div>
</div>
      <div class="col-md-3">
        <div class="text-center">
          <img src="//placehold.it/100" class="avatar img-circle" alt="avatar">
          <h6>Upload a different photo...</h6>
          
          <input type="file" class="form-control">
        </div>
      </div>
      
      <!-- edit form column -->
      <div class="col-md-9 personal-info">
        <div class="alert alert-info alert-dismissable">
          <a class="panel-close close" data-dismiss="alert">×</a> 
          <i class="fa fa-coffee"></i>
          <strong id="err-mes">.alert</strong>
		  <script> setAlert(); </script>
        </div>
        <h3>Personal info</h3>
        
        <form class="form-horizontal" action="changepassword.php" method="post" >
          <div class="form-group">
            <label class="col-lg-3 control-label">First name:</label>
            <div class="col-lg-8">
              <input class="form-control" type="text" value="Jane" id="fname" readonly></input>
            </div>
          </div>
          <div class="form-group">
            <label class="col-lg-3 control-label">Last name:</label>
            <div class="col-lg-8">
              <input class="form-control" type="text" value="Bishop" id="lname" readonly>
            </div>
          </div>
          <div class="form-group">
            <label class="col-lg-3 control-label">Desk Phone:</label>
            <div class="col-lg-8">
              <input class="form-control" type="text" value="" id="deskphone" readonly>
            </div>
          </div>
		  <div class="form-group">
            <label class="col-lg-3 control-label">Mobile Phone:</label>
            <div class="col-lg-8">
              <input class="form-control" type="text" value="" name="mobilephone" id="mobilephone">
            </div>
          </div>
          <div class="form-group">
            <label class="col-lg-3 control-label">Email:</label>
            <div class="col-lg-8">
              <input class="form-control" type="text" value="" name="email" id="email">
            </div>
          </div>
		  
          <div class="form-group">
            <label class="col-md-3 control-label">Change Password:</label>
            <div class="col-md-8">
              <input class="form-control" type="password" placeholder="" name="changepassword">
            </div>
          </div>
          <div class="form-group">
            <label class="col-md-3 control-label">Confirm Password:</label>
            <div class="col-md-8">
              <input class="form-control" type="password" placeholder="" name="confirmpassword">
            </div>
          </div>
          <div class="form-group">
            <label class="col-md-3 control-label"></label>
            <div class="col-md-8">
              <input type="submit" name="save" class="btn btn-primary" value="Save Changes">
              <span></span>
            </div>
          </div>
        </form>
      </div>
  </div>
</div>
<hr>

<script> 
	function fillEmployeeInfo()
	{
		var emp;

		var xmlhttp = new XMLHttpRequest({mozSystem: true});
		var url = "http://localhost/calpers/home/php/getemployee.php";
		
		xmlhttp.onreadystatechange = function() {
			if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
				emp = JSON.parse(xmlhttp.responseText);
				fillEmployeeValues(emp);
			}
		};
		
		xmlhttp.open("POST", url, true);
		xmlhttp.send();
		
		
	}
	
	function fillEmployeeValues(emp)
	{
		var dphone = emp["desk_phone"];
		var mphone = emp["mobile_phone"];
		document.getElementById("fname").value = emp['first_name'];
		document.getElementById("lname").value = emp["last_name"];
		document.getElementById("email").value = emp["email"];
		document.getElementById("deskphone").value = dphone.substr(0,1) + " (" + dphone.substr(1,3) + ") " 
						+ dphone.substr(4,3) + "-" + dphone.substr(7, 4);
		document.getElementById("mobilephone").value = mphone.substr(0,1) + " (" + mphone.substr(1,3) + ") " 
						+ mphone.substr(4,3) + "-" + mphone.substr(7, 4);
	}
	fillEmployeeInfo(); 
</script>
</body>

</html>