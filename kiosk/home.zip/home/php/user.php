<?php
error_reporting(E_ALL & E_NOTICE);
session_start();

if(isset($_SESSION['HRMS_ID'])){
	$userId = $_SESSION['HRMS_ID'];
	$email = $_SESSION['email'];
}else{
	header('Location: ../index.php');
	die();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Calpers</title>
    <meta charset="utf-8">
    <!--viewport is just the screen make consistent in all pages-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="C:\Users\Gad Frey\Desktop\bootstrap\css\my.css">
	<link rel="stylesheet" type="text/css" href="../css/calpers_style.css">
		
	<script>
		var filter = "name";
		var search = "";
		var asc = true;
		
		function showList(str)
		{
			search = str;
			var xmlhttp = new XMLHttpRequest({mozSystem: true});
			var url = "http://localhost/calpers/home/php/table_create.php?search=";
			
			xmlhttp.onreadystatechange = function() {
				if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
					document.getElementById("empTable").innerHTML = xmlhttp.responseText;
				}
			};
			
			xmlhttp.open("GET", url + str + "&filter=" + filter + "&ascending=" + asc, true);
			xmlhttp.send();
		}
		
		function changeFilter($name)
		{
			switch($name)
			{
				case("name"):
					if (filter != "name") { asc = true; }
					else { asc = !asc; }
						
					filter = "name";
					break;
				case("job_title"):
					if (filter != "job_title") { asc = true; }
					else
						asc = !asc;

					filter = "job_title";
					break;
				case("building"):
					if (filter != "building") { asc = true; }
					else
						asc = !asc;
						
					filter = "building";
					break;
				case("floor"):
					if (filter != "floor") { asc = true; }
					else { asc = !asc; }
						
					filter = "floor";
					break;
				default:
					filter = "name";
					asc = true;
			}
			
			showList(search);
		}
	</script>
	
</head>
<body>
<!--This part of the html controls the navagation bar-->
	<nav class="navbar navbar-inverse">
		<div class="container-fluid">
		<!--Logo-->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavBar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="#" class="navbar-brand">CALPERS</a>
			</div>

		<!--Menu Items-->
		<div class="collapse navbar-collapse" id="mainNavBar" align="center">
			<ul class="nav navbar-nav">
				<!--The href is the bottom the lets you go to different page-->
				<li class="active"><a href="#">Home</a></li>
				<li class=""><a href="profile.php">Edit-Profile</a></li>
				
			</ul>

			<!--right align outside the ul-->
			<ul class="nav navbar-nav navbar-right">
				<form class="btn btn-link" action="logout.php">
					<input type="submit" value="LogOut">
				</form>
			</ul>


		</div>

		<div class="flexsearch">
		  <div class="flexsearch--wrapper">
			<form class="flexsearch--form">
			  <div class="flexsearch--input-wrapper">
				<input class="flexsearch--input" type="text" placeholder="Search" onkeyup="showList(this.value)" name="val">
			  </div>
			  <input class="flexsearch--submit" text="submit" onsubmit="showList(val)" value="&#10140;"/>
			</form>
		  </div>
		</div>
		
	</nav>
	<p><div id="empTable"> </div></p>
	<script> showList(""); </script>
</body>
</html>