<?php

/*
This section of code of php handels the register part of the html.
This code inputs the value to the database that is entered.
*/

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "accounts";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
	
if($_POST['register']){
	$username=strip_tags($_POST['username']);
	$password=strip_tags($_POST['password']);


$sql = "INSERT INTO members (Id, username, password, activated) VALUES (NULL, '$username', '$password', '0')";

if (mysqli_query($conn, $sql)) {
    header('Location: index.php');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}
mysqli_close($conn);


?>