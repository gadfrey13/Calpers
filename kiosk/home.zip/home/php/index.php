<?php
error_reporting(E_ALL & ~E_NOTICE);
session_start();

if($_POST['login']){
	include_once("connection.php");
	$email		=strip_tags($_POST['email']);
	$password	=strip_tags($_POST['password']);

	$sql = "SELECT HRMS_ID, email, password FROM employee WHERE email = '$email'";
	$query = mysqli_query($dbCon,$sql);
 
	if($query){
		$row = mysqli_fetch_assoc($query);
		$userId = strip_tags($row['HRMS_ID']);
		$dbEmail = strip_tags($row['email']);
		$dbPassword = strip_tags($row['password']);
	} 
	
	if (strlen($email)>0 && strlen($password)>0) {
		if(strcmp($email, $dbEmail)==0 && strcmp($password, $dbPassword)==0){
			$_SESSION['email'] = $email;
			$_SESSION['HRMS_ID'] = $userId;
			header('Location: user.php');
	}
	
	header('Location: index.php?alert=' . urlencode('Username and Password Incorrect.'));
}


?>

<style type="text/css">
   body {
    background: white !important; 
    background-image: url("../image/calpers.jpg") !important;
    background-color: #cccccc !important;
    max-width: 100% !important;
    height: auto !important;
    } /* Adding !important forces the browser to overwrite the default style applied by Bootstrap */</style>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Calpers</title>
    <meta charset="utf-8">
    <!--viewport is just the screen make consistent in all pages-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="C:\Users\Gad Frey\Desktop\bootstrap\css\my.css">
    <link rel="stylesheet" type="text/css" href="C:\xampp\htdocs\bootstrap\CalPERs\SearchBar\csscalpers_style.css">

<!---------------------------------------------------------------------------------------------------->


<script> setAlert(); </script>
</head>
<body>
<!--This part of the html controls the navagation bar-->
	<nav class="navbar navbar-inverse">
		<div class="container-fluid">
		<!--Logo-->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mainNavBar">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a href="#" class="navbar-brand">CALPERS</a>
			</div>

		<!--Menu Items-->
		<div class="collapse navbar-collapse" id="mainNavBar" align="center">
			<ul class="nav navbar-nav">
				<!--The href is the bottom the lets you go to different page-->
				<li class="active"><a href="#">Main</a></li>
				<li><a href="#" class="btn btn-link" role="button" data-toggle="modal" data-target="#popUpWindowLogin">Log In</a></li>

			</ul>


		</div>

	</nav>
	<!--This part is for the register-->
	<div class="modal fade" id="popUpWindowLogin">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h3 class ="modal-title">Log-In</h3>
					</div>
			<form id="loginForm" action="index.php" method="post">
					<div class="modal-body">
							<div class="form-group">
								<input type="text" class="form-control" placeholder="Username" name="email"/><br/>
								<input type="password" class="form-control" placeholder="Password" name="password"/><br/>
								<strong id="err-mes"></strong>
							</div>
					</div>

					<div class="modal-footer">
								<input type="submit" name="login" class="btn btn-primary btn-block" value="Log In"/>
					</div>
			</form>
				</div>
			</div>
			<!--button-->
	</div>		
				
<!--This part of the html is for the Log In PopUP-->
	<div class="modal fade" id="popUpWIndowRegister">
		<div class="modal-dialog">
			<div class="modal-content">

				</form>
			</div>
		</div>
	</div>



<style media="screen" type="text/css"></style>

<script>
	function setAlert()
	{
		var thisurl = document.URL;
		
		if (thisurl.indexOf("=") > -1) {
			var left = thisurl.indexOf("=") + 1;
			var alert = thisurl.substring(left, thisurl.length);
			
			if (alert.indexOf("+") > -1)
				alert = alert.split("+").join(" ");
			if (alert.indexOf("%0A") > -1)
				alert = alert.split("%0A").join("<br>");
			if (alert.indexOf("%3A") > -1)
				alert = alert.split("%3A").join(":");
			if (alert.indexOf("%09") > -1)
				alert = alert.split("%09").join("&nbsp;&nbsp;&nbsp;&nbsp;");
			
			document.getElementById("err-mes").innerHTML = alert;
			$('#popUpWindowLogin').modal('show');
		}
	}
</script>


</body>
</html>