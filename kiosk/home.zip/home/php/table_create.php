<?php
	header('Access-Control-Allow-Origin: *'); 
    $servername = "localhost";
	$username 	= "root";
	$password 	= "";
	$dbName 	= "calpers";
	
	// Make Connection
	$connection = new mysqli($servername, $username, $password, $dbName);
	
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	
	$array = array();
	$search = $_REQUEST["search"];
	$filter = $_REQUEST["filter"];
	$asc    = $_REQUEST["ascending"];
	
	// Create query table based on inputted filter values
	if ($search !== "") {
		if ($filter == "name") {
			if ($asc == "true") {
				$query = "SELECT * FROM employee 
					WHERE first_name LIKE '%$search%' OR last_name LIKE '%$search%'
					ORDER BY first_name ASC";
			} else {
				$query = "SELECT * FROM employee 
					WHERE first_name LIKE '%$search%' OR last_name LIKE '%$search%'
					ORDER BY first_name DESC";
			}
		} else if ($filter == "job_title") {
			if ($asc == "true") {
				$query = "SELECT * FROM employee 
				WHERE first_name LIKE '%$search%' OR last_name LIKE '%$search%'
				ORDER BY job_title ASC";
			} else {
				$query = "SELECT * FROM employee 
				WHERE first_name LIKE '%$search%' OR last_name LIKE '%$search%'
				ORDER BY job_title DESC";
			}
		}  else if ($filter == "building") {
			if ($asc == "true") {
				$query = "SELECT * FROM employee 
					WHERE first_name LIKE '%$search%' OR last_name LIKE '%$search%'
					ORDER BY building ASC";
			} else {
				$query = "SELECT * FROM employee 
					WHERE first_name LIKE '%$search%' OR last_name LIKE '%$search%'
					ORDER BY building DESC";
			}
		} else if ($filter == "floor") {
			if ($asc == "true") {
				$query = "SELECT * FROM employee 
					WHERE first_name LIKE '%$search%' OR last_name LIKE '%$search%'
					ORDER BY floor ASC";
			} else {
				$query = "SELECT * FROM employee 
					WHERE first_name LIKE '%$search%' OR last_name LIKE '%$search%'
					ORDER BY floor DESC";
			}
		}
		
		// Check connection
	}
	else
	{
		if ($filter == "name") {
			if ($asc == "true") {
				$query = "SELECT * FROM employee ORDER BY first_name ASC";
			} else {
				$query = "SELECT * FROM employee ORDER BY first_name DESC";
			}
		} else if ($filter == "job_title") {
			if ($asc == "true") {
				$query = "SELECT * FROM employee ORDER BY job_title ASC";
			} else {
				$query = "SELECT * FROM employee ORDER BY job_title DESC";
			}
		} else if ($filter == "building") {
			if ($asc == "true") {
				$query = "SELECT * FROM employee ORDER BY building ASC";
			} else {
				$query = "SELECT * FROM employee ORDER BY building DESC";
			}
		} else if ($filter == "floor") {
			if ($asc == "true") {
				$query = "SELECT * FROM employee ORDER BY floor ASC";
			} else {
				$query = "SELECT * FROM employee ORDER BY floor DESC";
			}
		}
		
	}
	
	$result = mysqli_query($connection, $query);

	if (!$result)
		echo "Failure to query";
	else
	{
		while ($row = mysqli_fetch_assoc($result))
		{
			$array[] = $row;
		}
	}

	
	mysqli_close($connection);

	// desired number of columns - this can be any number
	$cols = 5;

	$output = "<table id =\"t01\" align=\"center\">";
	
	$output .= "<tr>";
	$output .= "<th onclick=\"changeFilter('name')\" style=\"cursor: pointer\">" . "Name" ."</th>\n";
	$output .= "<th onclick=\"changeFilter('job_title')\" style=\"cursor: pointer\">" . "Job Title" . "</th>\n";
	$output .= "<th>" . "Desk Phone" . "</th>\n";
	$output .= "<th onclick=\"changeFilter('building')\" style=\"cursor: pointer\">" . "Building" . "</th>\n";
	$output .= "<th onclick=\"changeFilter('floor')\" style=\"cursor: pointer\">" . "Floor" . "</th>\n";
	$output .= "</tr>";
	
	for ($i = 0; $i < count($array); $i++) {
		$hrms = $array[$i]["HRMS_ID"];
		$output .= "<tr onclick=\"location.href= 'http://localhost/calpers/home/profile/user-profile.html?hrms=". $hrms . "'\" style=\"cursor: pointer\">";
		$output .= "<td>" . $array[$i]["first_name"] . " " . $array[$i]["last_name"] . "</td>\n";
		$output .= "<td>" . $array[$i]["job_title"] . "</td>\n";
		$output .= "<td>" . substr($array[$i]["desk_phone"],0,1) . " (" . substr($array[$i]["desk_phone"],1,3) . ") " 
			. substr($array[$i]["desk_phone"],4,3) . "-" . substr($array[$i]["desk_phone"], 7, 4) . "</td>\n";
		$output .= "<td>" . $array[$i]["building"] . "</td>\n";
		$output .= "<td>" . $array[$i]["floor"] . "</td>\n";
		$output .= "</tr>";
	}
	$output .= "</tablet01>";
	
	echo $output;
?>