<?php
error_reporting(E_ALL & E_NOTICE);
session_start();
if(isset($_SESSION['HRMS_ID'])){
	header('Access-Control-Allow-Origin: *'); 
	$servername = "localhost";
	$username 	= "root";
	$password 	= "";
	$dbName 	= "calpers";
	
	// Make Connection
	$connection = new mysqli($servername, $username, $password, $dbName);
	
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	
	$hrms = $_SESSION["HRMS_ID"];

	if ($hrms !== "") {
		$query = "SELECT * FROM employee 
			WHERE HRMS_ID = $hrms";
	}
	else
	{
		return null;
	}
	
	$result = mysqli_query($connection, $query);
	mysqli_close($connection);
	
	
	if (!$result)
		echo "Failure to query";
	else
	{
		echo json_encode(mysqli_fetch_assoc($result));
	}
}
?>