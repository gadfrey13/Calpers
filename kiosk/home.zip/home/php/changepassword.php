<?php
	error_reporting(E_ALL & E_NOTICE);
	session_start();
	$connect = include_once("connection.php");
	
	
	if(isset($_SESSION['HRMS_ID'])){
		$err = ".alert:";
		$userId = $_SESSION['HRMS_ID'];
		
		$changepw = $_POST['changepassword'];
		$confpw   = $_POST['confirmpassword'];
		$phone    = $_POST['mobilephone'];
		$email    = $_POST['email'];
		$mphone;
		
		$mphone = preg_replace("/[^0-9,.]/", "", $phone);

		// Make Connection
		if (mysqli_connect_errno())
		{
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}
		
		$query = "select HRMS_ID, password, email, mobile_phone from employee WHERE HRMS_ID =" . $userId;
		
		$result = mysqli_query($dbCon, $query);
		$res = mysqli_fetch_assoc($result);
		
		
		if (!$res) {
			$err .= "\n\tCould Not Retrieve Information.";
		}
		
		// Change Password
		if (strlen($changepw) > 0 && strlen($confpw) > 0) {
			if (strcmp($changepw, $confpw) == 0) {
				if (mysqli_query($dbCon,"UPDATE employee 
										 SET password = '$changepw'
										 WHERE HRMS_ID = " . $userId)) 
				{
					$err .= "\n\tPassword Succesfully Changed.";
				} else {
					$err .= "\n\tFailed to Change Password.";
				}
			} else {
				$err .= "\n\tFailed to Change Password.";
			}
		}

		// Change Email
		if (strcmp($email, $res['email']) != 0) {
			if (mysqli_query($dbCon,"UPDATE employee 
									 SET email = '$email'
									 WHERE HRMS_ID =" . $userId)) {
				$err .= "\n\tEmail Succesfully Changed.";
			} else {
				$err .= "\n\tFailed to Change Email.";
			}
		} 
			
		// Change Mobile Phone Number
		if (strcmp($mphone, $res['mobile_phone']) != 0) {
			if (mysqli_query($dbCon,"UPDATE employee 
									 SET mobile_phone = '$mphone'
									 WHERE HRMS_ID =" . $userId)) {
				$err .= "\n\tMobile Phone Number Succesfully Changed.";
			} else {
				$err .= "\n\tFailed to Change Mobile Phone Number.";
			}
		}
	}
	
	header("Location: profile.php?alert=" . urlencode($err));
?>