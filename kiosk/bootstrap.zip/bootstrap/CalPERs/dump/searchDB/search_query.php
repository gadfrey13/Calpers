﻿<?php
	header('Access-Control-Allow-Origin: *'); 
    $servername = "athena.ecs.csus.edu";
	$username = "crimsontigers";
	$password = "crimsontigers_db";
	$dbName = "crimsontigers";
	
	// Make Connection
	$connection = new mysqli($servername, $username, $password, $dbName);
	
	$array = array();
	$search = $_REQUEST["search"];

	if ($search !== "") {
		$query = "SELECT * FROM employee 
		WHERE first_name LIKE '%$search%' OR last_name LIKE '%$search%'";
		// Check connection
		if (mysqli_connect_errno())
		{
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}
		
		$result = mysqli_query($connection, $query);
		
		if (!$result)
			echo "Failure to query";
		else
		{
			while ($row = mysqli_fetch_assoc($result))
			{
			$array[] = $row;
			}
		}
	}
	
	mysqli_close($connection);
?>