<?php
	include 'C:\xampp\htdocs\CalPERs\searchDB\employee_functions.php';
	header('Access-Control-Allow-Origin: *'); 
    $servername = "localhost";
	$username = "root";
	$password = "";
	$dbName = "calpers";
	
	// Make Connection
	$connection = new mysqli($servername, $username, $password, $dbName);

	$hrms = $_REQUEST["hrms"];

	// Check if connection was successful
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	} 
	else if ($hrms !== "") // check if GET was successful
	{
		$query = "SELECT * FROM employee 
			WHERE HRMS_ID = $hrms";
		
		$result = mysqli_query($connection, $query);
		
		if (!$result)
			echo "Failure to query";
		else
		{
			$emp = mysqli_fetch_assoc($result);
			
			$output = "<head> <br>\n";
			$output .= "<link rel='stylesheet' type='text/css' href='calpers_style.css'>";
			
			if ($emp !== null) 
			{
				$output .= "<h1>" . $emp["first_name"] . " " . $emp["last_name"] . "</h1> <br>\n";
				$output .= "<image src=\"" . $emp["photo"] . "\" /image> </head>\n";
				$output .= "<br>";
				
				$output .= "<p>";
				
				$output .= "<h1> Job Title: " . $emp["job_title"] . "</h1> <br>\n";
				$output .= "<h1> Desk Phone: " . createPhoneNumber($emp, 'desk_phone') . "</h1> <br>\n";
				$output .= "<h1> Mobile Phone: " . createPhoneNumber($emp, 'mobile_phone') . "</h1> <br>\n";
				$output .= "<h1> Email: " . $emp["email"] . "</h1> <br>\n";
				$output .= "<h1> Building: " . $emp["building"] . "</h1><br>\n";
				$output .= "<h1> Floor: " . $emp["floor"] . "</h1> <br>\n";
				$output .= "<br>";

				$output .= "</p>";
				
				echo $output;
			}
			else	// Failed to get Employee from query
			{
				echo "Employee Not Found";
			}
		}
	}
	else	// GET unsuccessful
	{
		echo "Failed to receive GET information\n";
	}


	
	mysqli_close($connection);
?>