﻿<?php
    $servername = "localhost";
	$username = "root";
	$password = "";
	$dbName = "calpers";
	
	// Make Connection
	$connection = new mysqli($servername, $username, $password, $dbName);
	$name = '';
	
	if (isset($_POST["search"]))
	{
		$name = $_POST['search'];
	}
    else
	{
		$user = null;
		echo "Failure to receive $_POST data";
	}
	
	
    $query = "SELECT * FROM employee 
	WHERE first_name LIKE '%$name%' OR last_name LIKE '%$name%'";

    // Check connection
    if (mysqli_connect_errno())
    {
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
	
	$result = mysqli_query($connection, $query);
	
	if (!$result)
		echo "Failure to query";
	else
	{
		while ($row = mysqli_fetch_array($result))
		{
			echo $row['first_name'] . " " . $row['last_name'];
			echo "<br>";
		}
	}
    mysqli_close($connection);
?>