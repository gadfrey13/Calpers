<?php
	header('Access-Control-Allow-Origin: *'); 
	libxml_use_internal_errors(true); 
    $servername = "localhost";
	$username = "root";
	$password = "";
	$dbName = "calpers";
	
	// Make Connection
	$connection = new mysqli($servername, $username, $password, $dbName);

	$hrms = $_REQUEST["hrms"];

	if ($hrms !== "") {
		$query = "SELECT * FROM employee 
			WHERE HRMS_ID = $hrms";
		// Check connection
		if (mysqli_connect_errno())
		{
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}
		
		$result = mysqli_query($connection, $query);
		
		if (!$result)
			echo "Failure to query";
		else
		{
			$emp = mysqli_fetch_assoc($result);
			
			echo "<link href='css/style.css' rel='stylesheet' type='text/css' media='all' />";
			
			$doc = new DOMDocument();
			$doc->recover = true;
			$doc->strictErrorChecking = false;
			
			if ($doc->loadHTMLFile('file:///C:/xampp/htdocs/CalPERs/ProfileView/EditProfile/index.html'))
			{
				$name = $doc->getElementById('emp-name');
				
				$name->setAttribute('value', $emp['first_name']);
				echo $doc->saveHTML();
				
			}
			
			
		}
	}

	
	mysqli_close($connection);
?>