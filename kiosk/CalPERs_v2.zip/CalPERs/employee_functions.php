<?php	
	/**
		createPhoneNumber:
			Takes an employee entity from "calpers" database,
			and returns employee's phone number in the form of: 
				(XXX) XXX - XXXX
			
			$employee : employee entity with all attributes
			$number   : mobile_phone, or desk_phone
	*/
	function createPhoneNumber($employee, $number)
	{
		if (is_array($employee))
		{
			if (!array_key_exists($number, $employee))
			{
				echo "field not in array\n";
				return null;
			}
			else if ($number === 'desk_phone' || $number === 'mobile_phone')
			{
				if ($number == 'desk_phone')
				{
					return substr($employee["desk_phone"],0,1) . " (" . substr($employee["desk_phone"],1,3) . ") " 
						. substr($employee["desk_phone"],4,3) . "-" . substr($employee["desk_phone"], 7, 4);
				}
				else
				{
					return substr($employee["mobile_phone"],0,1) . " (" . substr($employee["mobile_phone"],1,3) . ") " 
						. substr($employee["mobile_phone"],4,3) . "-" . substr($employee["mobile_phone"], 7, 4);	
				}
			}
			else
			{
				echo "number must be 'desk_phone' or 'mobile_phone'";
			}
		}
		else
		{
			echo "employee parameter is not an array";
		}
	}// end createPhoneNumber
	
	function getEmployeeWithHrms($hrms)
	{
		header('Access-Control-Allow-Origin: *'); 
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbName = "calpers";
		
		// Make Connection
		$connection = new mysqli($servername, $username, $password, $dbName);
		
		if (mysqli_connect_errno())
		{
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}
		
		$hrms = $_REQUEST["hrms"];

		if ($hrms !== "") {
			$query = "SELECT * FROM employee 
				WHERE HRMS_ID = $hrms";
		}
		else
		{
			return null;
		}
		
		$result = mysqli_query($connection, $query);

		if (!$result)
			echo "Failure to query";
		else
		{
			echo json_encode(mysqli_fetch_assoc($result));
		}

		
		mysqli_close($connection);
	}
	
?>