<?php

	header('Access-Control-Allow-Origin: *'); 
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbName = "calpers";
	
	// Make Connection
	$connection = new mysqli($servername, $username, $password, $dbName);
	
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}
	
	$hrms = $_REQUEST["hrms"];

	if ($hrms !== "") {
		$query = "SELECT * FROM employee 
			WHERE HRMS_ID = $hrms";
	}
	else
	{
		return null;
	}
	
	$result = mysqli_query($connection, $query);

	if (!$result)
		echo "Failure to query";
	else
	{
		echo json_encode(mysqli_fetch_assoc($result));
	}

	
	mysqli_close($connection);
	
?>