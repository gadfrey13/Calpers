<?php
	header('Access-Control-Allow-Origin: *'); 
    $servername = "localhost";
	$username = "root";
	$password = "";
	$dbName = "calpers";
	
	// Make Connection
	$connection = new mysqli($servername, $username, $password, $dbName);

	$hrms = $_REQUEST["hrms"];

	if ($hrms !== "") {
		$query = "SELECT * FROM employee 
			WHERE HRMS_ID = $hrms";
		// Check connection
		if (mysqli_connect_errno())
		{
			echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}
		
		$result = mysqli_query($connection, $query);
		
		if (!$result)
			echo "Failure to query";
		else
		{
			$emp = mysqli_fetch_assoc($result);
			
			$output = "<head> <br>\n";
			$output .= "<link rel='stylesheet' type='text/css' href='calpers_style.css'>";
			
			if ($emp !== null) 
			{
				$output .= "<h1>" . $emp["first_name"] . " " . $emp["last_name"] . "</h1> <br>\n";
				$output .= "<image src=\"" . $emp["photo"] . "\" /image> </head>\n";
				$output .= "<br>";
				
				$output .= "<p>";
				
				$output .= "<h1> Job Title: " . $emp["job_title"] . "</h1> <br>\n";
				$output .= "<h1> Desk Phone: " . substr($emp["desk_phone"],0,1) . " (" . substr($emp["desk_phone"],1,3) . ") " 
					. substr($emp["desk_phone"],4,3) . "-" . substr($emp["desk_phone"], 7, 4) . "</h1> <br>\n";
				$output .= "<h1> Mobile Phone: " . substr($emp["mobile_phone"],0,1) . " (" . substr($emp["mobile_phone"],1,3) . ") " 
					. substr($emp["mobile_phone"],4,3) . "-" . substr($emp["mobile_phone"], 7, 4) . "</h1> <br>\n";
				$output .= "<h1> Email: " . $emp["email"] . "</h1> <br>\n";
				$output .= "<h1> Building: " . $emp["building"] . "</h1><br>\n";
				$output .= "<h1> Floor: " . $emp["floor"] . "</h1> <br>\n";
				$output .= "<br>";

				$output .= "</p>";
				
				echo $output;
			}
			else
			{
				echo "Employee Not Found";
			}
		}
	}

	
	mysqli_close($connection);
?>