<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbName = "calpers";
	
	// Make Connection
	$connection = new mysqli($servername, $username, $password, $dbName);
	
	// Check Connection
	if(!$connection) {
		die("Connection Failed .".mysqli_connect_error());
	} 
	
	$sql = "SELECT * FROM employee";
	$result = mysqli_query($connection, $sql);
	
	if(mysqli_num_rows($result)> 0) {
		// show data
		while ($row = mysqli_fetch_assoc($result)){
			echo "first_name".$row['first_name'] . "|last_name".$row['last_name'] . "|HRMS_ID".$row['HRMS_ID'] 
			. "|photo".$row['photo'] . "|empl_classification".$row['empl_classification'] 
			. "|job_title".$row['job_title'] . "|desk_phone".$row['desk_phone'] 
			. "|mobile_phone".$row['mobile_phone'] . "|grid_location".$row['grid_location'] 
			. "|building".$row['building'] . "|floor".$row['floor'] . "|email".$row['email']
			. "|access_door".$row['access_door'] . "|division".$row['division'] 
			. "|unit".$row['unit'] . "|manager".$row['manager'] . ";";
		}
	}
?>